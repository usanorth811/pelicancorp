INTRODUCTION
------------

The downloaded example may contain several different file types outlined below. Use whichever is most appropriate for your system and process. 

### Email files
* .eml - An email file, this example email is a demonstration of what will be delivered to members who use email to recieve their tickets. 
* .pdf - The pdf files contained may be either a copy of the email body (included for your convenience), or the attached pdf version of the ticket.
* .gml .xml .gif - These are the example tickets that are included as attachments on the email.




### Contact
If you encounter any issues with the attached files, or would like further assistance or explanations of any of the contained, contact us a memberservices@usanorth811.org